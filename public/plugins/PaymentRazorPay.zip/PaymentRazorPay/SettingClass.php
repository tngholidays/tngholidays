<?php
namespace Plugins\PaymentRazorPay;

use Modules\Core\Abstracts\BaseSettingsClass;

class SettingClass extends BaseSettingsClass
{
    public static function getSettingPages()
    {
        return [];
    }
}
